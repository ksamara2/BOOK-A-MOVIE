## Folder related to the login of the system

Libraries utilized:
   
- pycryptodome (for encryption of passwords) [pip install pycryptodome]
- pytest (for unit tests) [pip install pytest]